RMz NJB inject

For LiveContainer on non-jailbroken devices. Put both items in LiveContainer's
Tweaks folder, side by side in the same folder:

  RMzModMenu.dylib
  RMz.framework

Keep only one RMz client and one RMz.framework in a shared Tweaks folder.
For Feather, ESign or Sideloadly, use the RMz-Sideload .deb instead.
